# fastapi-mako
Mako templaye support for FastAPI
